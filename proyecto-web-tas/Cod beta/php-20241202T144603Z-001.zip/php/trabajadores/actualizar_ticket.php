<?php
session_start(); // Iniciar la sesión

// Verificar si el usuario está logueado
if (!isset($_SESSION['trabajador_id'])) {
    header('Location: ../../html/trabajador'); // Redirigir al login
    exit();
}
include '../config.php';

$data = json_decode(file_get_contents('php://input'), true);

// Verificar que los datos llegaron correctamente
if (isset($data['cambios'])) {
    $cambios = $data['cambios'];

    // Iterar sobre los cambios
    foreach ($cambios as $cambio) {
        $id_ticket = $cambio['id'];
        $nuevo_estado = $cambio['estado'];

        // Verificar si el nuevo estado es válido
        if (!in_array($nuevo_estado, ['abierta', 'en progreso', 'cerrada'])) {
            echo json_encode(['success' => false, 'error' => 'Estado inválido: ' . $nuevo_estado]);
            exit;
        }

        // Actualizar estado del ticket en la base de datos
        $sql = "UPDATE incidencias SET estado = ? WHERE id_incidencia = ?";
        $stmt = $conexion->prepare($sql);
        $stmt->bind_param('si', $nuevo_estado, $id_ticket);

        if ($stmt->execute()) {
            // Éxito en la actualización
            echo json_encode(['success' => true]);
        } else {
            // Error al actualizar
            echo json_encode(['success' => false, 'error' => 'Error al actualizar el ticket con ID ' . $id_ticket]);
            exit;
        }
    }

} else {
    echo json_encode(['success' => false, 'error' => 'Datos inválidos']);
}
?>
