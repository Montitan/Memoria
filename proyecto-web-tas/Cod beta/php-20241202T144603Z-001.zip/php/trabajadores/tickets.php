<?php
session_start(); // Iniciar la sesión

// Verificar si el usuario está logueado
if (!isset($_SESSION['trabajador_id'])) {
    header('Location: ../../html/trabajador'); // Redirigir al login
    exit();
}

include '../config.php'; // Incluir la configuración de conexión a la base de datos


// Actualizar estado del ticket
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Obtener los datos de la solicitud
    $data = json_decode(file_get_contents('php://input'), true);
    if (isset($data['id']) && isset($data['estado'])) {
        // Incluir el archivo de configuración para la base de datos
        include '../config.php'; // Cambia la ruta según tu configuración

        $id_incidencia = (int) $data['id']; // ID del ticket
        $estado = $conexion->real_escape_string($data['estado']); // Estado del ticket

        // Validar el estado
        $estados_validos = ['abierta', 'en progreso', 'cerrada'];
        if (in_array($estado, $estados_validos)) {
            // Actualizar el estado del ticket en la base de datos
            $sql = "UPDATE incidencias SET estado = '$estado' WHERE id_incidencia = $id_incidencia";
            if ($conexion->query($sql) === TRUE) {
                echo json_encode(['success' => true]);
            } else {
                echo json_encode(['success' => false, 'error' => $conexion->error]);
            }
        } else {
            echo json_encode(['success' => false, 'error' => 'Estado no válido']);
        }
    } else {
        echo json_encode(['success' => false, 'error' => 'Datos inválidos']);
    }
}
?>

<?php
// Consultar todos los tickets
$sql = "SELECT * FROM incidencias";
$result = $conexion->query($sql);

// Comprobar si se encontraron tickets
$tickets = [];
if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        $tickets[] = $row;
    }
} else {
    echo "No se encontraron tickets.";
}

?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tablero de Tickets</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f9f9f9;
            margin: 0;
            padding: 0;
        }
        .kanban-board {
            display: flex;
            justify-content: space-around;
            margin: 20px;
        }
        .kanban-column {
            width: 30%;
            background-color: #fff;
            border: 1px solid #ddd;
            border-radius: 5px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
        }
        .kanban-column h3 {
            text-align: center;
            background-color: #007bff;
            color: #fff;
            padding: 10px;
            margin: 0;
            border-radius: 5px 5px 0 0;
        }
        .kanban-column .ticket-list {
            min-height: 200px;
            padding: 10px;
        }
        .ticket {
            background-color: #f4f4f4;
            margin: 10px 0;
            padding: 10px;
            border-radius: 5px;
            box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
            cursor: move;
        }
    </style>
</head>
<body>
    <div class="kanban-board">
        <!-- Abierto -->
        <div class="kanban-column" id="open-column">
            <h3>Abierto</h3>
            <div class="ticket-list" id="abierto">
                <?php foreach ($tickets as $ticket): ?>
                    <?php if ($ticket['estado'] === 'abierta'): ?>
                        <div class="ticket" draggable="true" data-id="<?= $ticket['id_incidencia']; ?>">
                            <strong><?= htmlspecialchars($ticket['titulo']); ?></strong>
                            <p><?= htmlspecialchars($ticket['descripcion']); ?></p>
                        </div>
                    <?php endif; ?>
                <?php endforeach; ?>
            </div>
        </div>

        <!-- En Progreso -->
        <div class="kanban-column" id="in-progress-column">
            <h3>En Progreso</h3>
            <div class="ticket-list" id="en_progreso">
                <?php foreach ($tickets as $ticket): ?>
                    <?php if ($ticket['estado'] === 'en progreso'): ?>
                        <div class="ticket" draggable="true" data-id="<?= $ticket['id_incidencia']; ?>">
                            <strong><?= htmlspecialchars($ticket['titulo']); ?></strong>
                            <p><?= htmlspecialchars($ticket['descripcion']); ?></p>
                        </div>
                    <?php endif; ?>
                <?php endforeach; ?>
            </div>
        </div>

        <!-- Cerrado -->
        <div class="kanban-column" id="closed-column">
            <h3>Cerrado</h3>
            <div class="ticket-list" id="cerrado">
                <?php foreach ($tickets as $ticket): ?>
                    <?php if ($ticket['estado'] === 'cerrada'): ?>
                        <div class="ticket" draggable="true" data-id="<?= $ticket['id_incidencia']; ?>">
                            <strong><?= htmlspecialchars($ticket['titulo']); ?></strong>
                            <p><?= htmlspecialchars($ticket['descripcion']); ?></p>
                        </div>
                    <?php endif; ?>
                <?php endforeach; ?>
            </div>
        </div>
    </div>

    <script>
        const tickets = document.querySelectorAll('.ticket');
        const columns = document.querySelectorAll('.ticket-list');

        let draggedTicket = null;

        tickets.forEach(ticket => {
            ticket.addEventListener('dragstart', () => {
                draggedTicket = ticket;
                setTimeout(() => ticket.style.display = 'none', 0);
            });

            ticket.addEventListener('dragend', () => {
                setTimeout(() => {
                    draggedTicket.style.display = 'block';
                    draggedTicket = null;
                }, 0);
            });
        });

        columns.forEach(column => {
            column.addEventListener('dragover', (e) => {
                e.preventDefault();
            });

            column.addEventListener('drop', () => {
                if (draggedTicket) {
                    column.appendChild(draggedTicket);

                    // Enviar la actualización del estado al servidor
                    const ticketId = draggedTicket.getAttribute('data-id');
                    const nuevoEstado = column.id; // abierto, en_progreso, cerrado

                    fetch('actualizar_ticket.php', {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify({ id: ticketId, estado: nuevoEstado })
                    }).then(response => response.json())
                      .then(data => {
                          if (!data.success) {
                              console.error('Error al actualizar el estado del ticket:', data.error);
                          }
                      }).catch(error => {
                          console.error('Error en la solicitud:', error);
                      });
                }
            });
        });
    </script>
</body>
</html>

