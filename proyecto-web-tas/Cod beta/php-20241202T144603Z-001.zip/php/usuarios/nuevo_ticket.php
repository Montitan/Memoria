<?php
include '../config.php';
session_start();

if (!isset($_SESSION['user_id'])) {
    header('Location: ../../html/ybtva-ertvfgre.html');
    exit();
}

$titulo = $_POST['ticketTitle'];
$descripcion = $_POST['ticketDescription'];
$prioridad = $_POST['ticketPriority'];
$categoria = $_POST['ticketCategory'];
$id_usuario = $_SESSION['user_id']; 

$fecha_creacion = date('Y-m-d H:i:s');

// Primero obtenemos el id_tematica de la categoría seleccionada
$query = "SELECT id_tematica FROM categorias WHERE nombre_categoria = ?";
$stmt_categoria = $conexion->prepare($query);
$stmt_categoria->bind_param("s", $categoria);
$stmt_categoria->execute();
$result = $stmt_categoria->get_result();
$category_row = $result->fetch_assoc();
$id_tematica = $category_row['id_tematica'] ?? NULL;

// Ahora preparamos la sentencia SQL para insertar la incidencia
$sql = "INSERT INTO incidencias (titulo, descripcion, fecha_creacion, estado, prioridad, id_usuario, id_tematica)
        VALUES (?, ?, ?, 'abierta', ?, ?, ?)";
$stmt = $conexion->prepare($sql);

// Verificamos si la preparación fue exitosa
if ($stmt === false) {
    die('Error al preparar la consulta: ' . $conexion->error);
}

// Vinculamos los parámetros a la declaración preparada
$stmt->bind_param("ssssii", $titulo, $descripcion, $fecha_creacion, $prioridad, $id_usuario, $id_tematica);

// Ejecutamos la consulta
if ($stmt->execute()) {
    echo "Incidencia guardada exitosamente.";
    header("Location: usuario-ticket.php");
} else {
    echo "Error al guardar incidencia: " . $stmt->error;
}

// Cerramos la declaración y la conexión
$stmt->close();
$conexion->close();
?>
