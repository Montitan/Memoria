<?php
include '../config.php';
session_start();

if (!isset($_SESSION['user_id'])) {
    header('Location: ../../html/ybtva-ertvfgre.html');
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Recibimos los datos enviados desde el formulario
    $ticket_id = $_POST['ticket_id'];
    $titulo = $_POST['ticketTitle'];
    $descripcion = $_POST['ticketDescription'];
    $prioridad = $_POST['ticketPriority'];
    $id_usuario = $_SESSION['user_id'];

    // Ahora preparamos la sentencia SQL para actualizar la incidencia
    $sql = "UPDATE incidencias 
            SET titulo = ?, descripcion = ?, prioridad = ? 
            WHERE id_incidencia = ? AND id_usuario = ?";
    
    // Preparar la consulta
    $stmt = $conexion->prepare($sql);

    if ($stmt === false) {
        die('Error al preparar la consulta: ' . $conexion->error);
    }

    // Vinculamos los parámetros a la declaración preparada
    $stmt->bind_param("sssii", $titulo, $descripcion, $prioridad, $ticket_id, $id_usuario);

    // Ejecutamos la consulta
    if ($stmt->execute()) {
        // Si la actualización fue exitosa, redirigimos al usuario al dashboard
        header("Location: user_dashboard.php");
        exit();
    } else {
        echo "Error al actualizar el ticket: " . $stmt->error;
    }

    // Cerramos la declaración y la conexión
    $stmt->close();
    $conexion->close();
}
?>
