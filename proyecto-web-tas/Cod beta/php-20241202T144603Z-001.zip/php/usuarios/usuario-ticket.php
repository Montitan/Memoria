<?php
session_start(); // Iniciar la sesión

// Verificar si el usuario está logueado
if (!isset($_SESSION['user_id'])) {
    // Si no está logueado, redirigir al login
    header('Location: ../../html/ybtva-ertvfgre.html');
    exit();
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Crear Ticket</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
    <style>
        body {
            background-color: #f8f9fa;
            padding: 20px;
        }
        .container {
            max-width: 600px;
            margin: 0 auto;
        }
        .form-title {
            text-align: center;
            margin-bottom: 20px;
        }
    </style>
</head>
<body>

<div class="container">
    <h2 class="form-title">Crear Nuevo Ticket</h2>
    
    <form action="nuevo_ticket.php" method="POST">
    <!-- Campo para el Título del Ticket -->
    <div class="form-group">
        <label for="ticketTitle">Título del Ticket</label>
        <input type="text" class="form-control" id="ticketTitle" name="ticketTitle" required placeholder="Escribe el título del ticket">
    </div>

    <!-- Campo para la Descripción del Ticket -->
    <div class="form-group">
        <label for="ticketDescription">Descripción</label>
        <textarea class="form-control" id="ticketDescription" name="ticketDescription" required placeholder="Describe tu problema o solicitud" rows="4"></textarea>
    </div>

    <!-- Campo para la Prioridad del Ticket -->
    <div class="form-group">
        <label for="ticketPriority">Prioridad</label>
        <select class="form-control" id="ticketPriority" name="ticketPriority" required>
            <option value="baja">Baja</option>
            <option value="media">Media</option>
            <option value="alta">Alta</option>
        </select>
    </div>

    <!-- Campo para la Categoría del Ticket -->
    <div class="form-group">
        <label for="ticketCategory">Categoría</label>
        <select class="form-control" id="ticketCategory" name="ticketCategory" required>
            <option value="problema-tecnico">Problema Técnico</option>
            <option value="solicitud-soporte">Solicitud de Soporte</option>
            <option value="otro">Otro</option>
        </select>
    </div>

    <div class="d-flex">
        <!-- Botón Crear Ticket (envía el formulario) -->
        <button type="submit" class="btn btn-primary flex-grow-1 mr-2">
            <i class="fas fa-plus mr-2"></i>Crear Ticket
        </button>

        <!-- Botón Volver -->
        <a href="user_dashboard.php" class="btn btn-danger flex-grow-1">
            <i class="fas fa-sign-out-alt mr-2"></i>Volver
        </a>
    </div>
</form>

</div>

<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
</body>
</html>
