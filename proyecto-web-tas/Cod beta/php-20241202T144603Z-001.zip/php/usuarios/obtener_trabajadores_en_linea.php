<?php
include '../config.php'; // Incluir la configuración de conexión a la base de datos

// Consulta para obtener los trabajadores activos
$sql_trabajadores = "SELECT id_trabajador, nombre, apellido, cargo FROM trabajadores WHERE estado = 'activo'";
$stmt_trabajadores = $conexion->prepare($sql_trabajadores);
$stmt_trabajadores->execute();
$result_trabajadores = $stmt_trabajadores->get_result();

// Crear un arreglo para los trabajadores en línea
$trabajadores_en_linea = [];
while ($trabajador = $result_trabajadores->fetch_assoc()) {
    $trabajadores_en_linea[] = $trabajador;
}

// Devolver los trabajadores en línea en formato JSON
echo json_encode($trabajadores_en_linea);

// Cerrar la conexión
$stmt_trabajadores->close();
$conexion->close();
?>
