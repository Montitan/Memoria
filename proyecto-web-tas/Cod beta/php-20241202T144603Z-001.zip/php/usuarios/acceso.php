<?php
include '../config.php';

if ($_SERVER["REQUEST_METHOD"] === "POST") {

    // Registro de usuario
    if (isset($_POST['register'])) {
        $nombre = $_POST['nombre'];
        $apellido = $_POST['apellido'];
        $email = $_POST['email'];
        $password = password_hash($_POST['password'], PASSWORD_DEFAULT); // Hashear la contraseña

        // Insertar nuevo usuario en la base de datos
        $sql = "INSERT INTO Usuarios (nombre, apellido, email, contraseña, fecha_registro, ultima_actividad) 
                VALUES ('$nombre', '$apellido', '$email', '$password', CURDATE(), NOW())";

        if ($conexion->query($sql) === TRUE) {
            echo "Registro exitoso.";
        } else {
            echo "Error: " . $conexion->error;
        }

    } elseif (isset($_POST['login'])) {
        // Inicio de sesión
        $email = $_POST['email'];
        $password = $_POST['password'];

        $sql = "SELECT * FROM Usuarios WHERE email='$email'";
        $result = $conexion->query($sql);

        if ($result->num_rows > 0) {
            $user = $result->fetch_assoc(); // Obtener los datos del usuario

            // Verificar la contraseña con password_verify() comparando la contraseña proporcionada con la almacenada (cifrada)
            if (password_verify($password, $user['contraseña'])) {
                // Inicio de sesión exitoso, se guardan los datos en la sesión y se redirige al dashboard
                session_start(); // Iniciar la sesión
                $_SESSION['user_id'] = $user['id_usuario'];  // Almacenar ID del usuario en la sesión
                $_SESSION['nombre'] = $user['nombre'];      // Almacenar el nombre en la sesión

                // Actualizar la última actividad para marcar al usuario como activo
                $sql_update_activity = "UPDATE Usuarios SET ultima_actividad = NOW() WHERE id_usuario = ?";
                $stmt_update_activity = $conexion->prepare($sql_update_activity);
                $stmt_update_activity->bind_param("i", $user['id_usuario']);
                $stmt_update_activity->execute();

                // Redirigir al Dashboard
                header('Location: user_dashboard.php');
                exit(); // Asegura que el script se detenga después de redirigir
            } else {
                echo "Contraseña incorrecta.";
            }
        } else {
            echo "El usuario no existe.";
        }
    }
}
?>
