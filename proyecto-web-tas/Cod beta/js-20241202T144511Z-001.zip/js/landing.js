
document.addEventListener('DOMContentLoaded', function() {
    const hamburger = document.querySelector('.hamburger');
    const navMenu = document.querySelector('.nav-menu');

    hamburger.addEventListener('click', function() {
        navMenu.classList.toggle('active');
    });
});

document.addEventListener('DOMContentLoaded', function() {
    // Animación de entrada para el hero
    const heroContent = document.querySelector('.hero-content');
    heroContent.classList.add('animate__animated', 'animate__fadeInLeft');

    const heroImage = document.querySelector('.hero-image');
    heroImage.classList.add('animate__animated', 'animate__fadeInRight');

    // Contador de estadísticas
    function animateValue(obj, start, end, duration) {
        let startTimestamp = null;
        const step = (timestamp) => {
            if (!startTimestamp) startTimestamp = timestamp;
            const progress = Math.min((timestamp - startTimestamp) / duration, 1);
            obj.innerHTML = Math.floor(progress * (end - start) + start);
            if (progress < 1) {
                window.requestAnimationFrame(step);
            }
        };
        window.requestAnimationFrame(step);
    }

    const statsElements = document.querySelectorAll('.stat-value');
    statsElements.forEach(el => {
        const endValue = parseInt(el.getAttribute('data-value'));
        animateValue(el, 0, endValue, 2000);
    });

    // Carrusel de testimonios mejorado
    const testimonialCarousel = document.querySelector('.testimonial-carousel');
    const testimonials = document.querySelectorAll('.testimonial');
    let currentTestimonial = 0;

    function showTestimonial(index) {
        testimonials.forEach((t, i) => {
            t.style.transform = `translateX(${100 * (i - index)}%)`;
        });
    }

    function nextTestimonial() {
        currentTestimonial = (currentTestimonial + 1) % testimonials.length;
        showTestimonial(currentTestimonial);
    }

    setInterval(nextTestimonial, 5000);
    showTestimonial(currentTestimonial);

    // Animación para las tarjetas de características
    const featureCards = document.querySelectorAll('.feature-card');
    featureCards.forEach(card => {
        card.addEventListener('mouseenter', () => {
            card.classList.add('animate__animated', 'animate__pulse');
        });
        card.addEventListener('mouseleave', () => {
            card.classList.remove('animate__animated', 'animate__pulse');
        });
    });

    // Animación de scroll para secciones
    const sections = document.querySelectorAll('section');
    const options = {
        threshold: 0.1,
        rootMargin: "0px 0px -100px 0px"
    };

    const observer = new IntersectionObserver((entries, observer) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.classList.add('animate__animated', 'animate__fadeInUp');
                observer.unobserve(entry.target);
            }
        });
    }, options);

    sections.forEach(section => {
        observer.observe(section);
    });

    // Formulario de contacto dinámico
    const contactForm = document.getElementById('contact-form');
    if (contactForm) {
        contactForm.addEventListener('submit', function(e) {
            e.preventDefault();
            const formData = new FormData(this);
            const submitButton = this.querySelector('button[type="submit"]');
            submitButton.disabled = true;
            submitButton.textContent = 'Enviando...';

            // Simular envío de formulario (reemplazar con llamada API real)
            setTimeout(() => {
                submitButton.textContent = '¡Enviado!';
                submitButton.classList.add('success');
                this.reset();
                setTimeout(() => {
                    submitButton.disabled = false;
                    submitButton.textContent = 'Enviar';
                    submitButton.classList.remove('success');
                }, 3000);
            }, 2000);
        });
    }

    // Cambio dinámico de planes de precios
    const pricingToggle = document.getElementById('pricing-toggle');
    const monthlyPrices = document.querySelectorAll('.price-monthly');
    const yearlyPrices = document.querySelectorAll('.price-yearly');

    if (pricingToggle) {
        pricingToggle.addEventListener('change', function() {
            if (this.checked) {
                monthlyPrices.forEach(p => p.style.display = 'none');
                yearlyPrices.forEach(p => p.style.display = 'block');
            } else {
                monthlyPrices.forEach(p => p.style.display = 'block');
                yearlyPrices.forEach(p => p.style.display = 'none');
            }
        });
    }

    // Smooth scrolling mejorado
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function (e) {
            e.preventDefault();
            const targetId = this.getAttribute('href');
            const targetElement = document.querySelector(targetId);
            if (targetElement) {
                targetElement.scrollIntoView({
                    behavior: 'smooth',
                    block: 'start'
                });
            }
        });
    });

    // Botón de "Volver arriba"
    const scrollToTopButton = document.getElementById('scroll-to-top');
    if (scrollToTopButton) {
        window.addEventListener('scroll', () => {
            if (window.pageYOffset > 300) {
                scrollToTopButton.style.display = 'block';
            } else {
                scrollToTopButton.style.display = 'none';
            }
        });

        scrollToTopButton.addEventListener('click', () => {
            window.scrollTo({top: 0, behavior: 'smooth'});
        });
    }

    // Manejo mejorado de los botones CTA
    const ctaButtons = document.querySelectorAll('.cta-button');
    ctaButtons.forEach(button => {
        button.addEventListener('click', () => {
            button.classList.add('animate__animated', 'animate__rubberBand');
            setTimeout(() => {
                button.classList.remove('animate__animated', 'animate__rubberBand');
            }, 1000);
            // Aquí puedes agregar la lógica para iniciar la prueba gratuita
            console.log('Iniciando prueba gratuita...');
        });
    });
});

document.addEventListener('DOMContentLoaded', function() {
    // Animación de entrada para los miembros del equipo
    const teamMembers = document.querySelectorAll('.team-member');
    
    const observerOptions = {
        root: null,
        rootMargin: '0px',
        threshold: 0.1
    };

    const observer = new IntersectionObserver((entries, observer) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.classList.add('fade-in');
                observer.unobserve(entry.target);
            }
        });
    }, observerOptions);

    teamMembers.forEach(member => {
        observer.observe(member);
    });

    // Efecto hover para las imágenes de los miembros del equipo
    teamMembers.forEach(member => {
        const img = member.querySelector('img');
        member.addEventListener('mouseenter', () => {
            img.style.transform = 'scale(1.1)';
            img.style.transition = 'transform 0.3s ease';
        });
        member.addEventListener('mouseleave', () => {
            img.style.transform = 'scale(1)';
        });
    });

    // Modal para mostrar más información sobre cada miembro (opcional)
    teamMembers.forEach(member => {
        member.addEventListener('click', () => {
            // Aquí puedes implementar la lógica para mostrar un modal
            // con más información sobre el miembro del equipo
            console.log('Mostrar más información sobre:', member.querySelector('h3').textContent);
        });
    });
});

// Añade esto al final de tu archivo script.js existente
document.addEventListener('DOMContentLoaded', function() {
    const contactForm = document.getElementById('contact-form');
    if (contactForm) {
        contactForm.addEventListener('submit', function(e) {
            e.preventDefault();
            const formData = new FormData(this);
            const submitButton = this.querySelector('button[type="submit"]');
            submitButton.disabled = true;
            submitButton.textContent = 'Enviando...';

            // Simular envío de formulario (reemplazar con llamada API real)
            setTimeout(() => {
                submitButton.textContent = '¡Enviado!';
                submitButton.classList.add('success');
                this.reset();
                setTimeout(() => {
                    submitButton.disabled = false;
                    submitButton.textContent = 'Enviar Mensaje';
                    submitButton.classList.remove('success');
                }, 3000);
            }, 2000);
        });
    }
});