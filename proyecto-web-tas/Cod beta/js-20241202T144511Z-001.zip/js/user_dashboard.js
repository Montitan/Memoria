$(document).ready(function() {
    
    // Comprobar si el usuario tiene una preferencia guardada
    const modoGuardado = localStorage.getItem('modo');
    if (modoGuardado === 'oscuro') {
        activarModoOscuro();
        $('#darkModeSwitch').prop('checked', true); // Marcar el switch si está en modo oscuro
    }

    // Modo Oscuro: Alternar y guardar preferencia
    $('#darkModeSwitch').on('change', function() {
        if ($(this).is(':checked')) {
            activarModoOscuro();
        } else {
            desactivarModoOscuro();
        }
    });

    function activarModoOscuro() {
        $('body').addClass('dark-mode');
        $('.navbar').removeClass('bg-light').addClass('bg-dark'); // Cambiar a fondo oscuro
        $('.sidebar').addClass('bg-dark'); // Cambiar sidebar a fondo oscuro
        localStorage.setItem('modo', 'oscuro');
        $('.table').addClass('table-dark'); // Cambiar tabla a estilo oscuro
    }

    function desactivarModoOscuro() {
        $('body').removeClass('dark-mode');
        $('.navbar').removeClass('bg-dark').addClass('bg-light'); // Volver a fondo claro
        $('.sidebar').removeClass('bg-dark'); // Volver sidebar a fondo claro
        localStorage.removeItem('modo');
        
        // Restablecer tabla a su estado original
        $('.table').removeClass('table-dark'); // Volver tabla a estilo claro
    }

    // Función para actualizar la tabla según el filtro
    function actualizarTabla() {
        const estadoFiltro = $('#filtro-estado').val().toLowerCase().trim();
        const fechaFiltro = $('#filtro-fecha').val().trim();

        // Obtener todas las filas de la tabla
        $('#tabla-incidencias tbody tr').each(function() {
            const estadoFila = $(this).find('td:nth-child(2) .badge').text().toLowerCase().trim();
            const fechaFila = $(this).find('td:nth-child(3)').text().trim();

            let mostrarFila = true;

            // Filtrar por estado
            if (estadoFiltro && !estadoFila.includes(estadoFiltro)) {
                mostrarFila = false;
            }

            // Filtrar por fecha
            if (fechaFiltro && fechaFiltro !== fechaFila) {
                mostrarFila = false;
            }

            // Mostrar u ocultar la fila
            $(this).toggle(mostrarFila);
        });
    }

    // Detectar cambios en los filtros
    $('#filtro-estado, #filtro-fecha').on('change', actualizarTabla);

    // Inicializar tabla
    actualizarTabla();

    // Manejo del formulario de contacto
    $('#contact-form').on('submit', function(e) {
        e.preventDefault();
        alert('Gracias por tu mensaje. Te contactaremos pronto.');
        this.reset(); // Reiniciar el formulario después del envío
    });
});
// Función para obtener los trabajadores en línea desde el servidor
function obtenerTrabajadoresEnLinea() {
    fetch('obtener_trabajadores_en_linea.php')
        .then(response => response.json())
        .then(data => {
            // Limpiar la lista de trabajadores antes de agregar los nuevos
            const userCards = document.querySelector('.user-cards');
            userCards.innerHTML = '';  // Limpiar la lista de trabajadores

            // Agregar los trabajadores a la interfaz
            data.forEach(trabajador => {
                const userCard = document.createElement('div');
                userCard.classList.add('user-card');
                userCard.innerHTML = `
                    <div class="status-indicator"></div> <!-- Punto verde aquí -->
                    <img src="../../assets/${trabajador.nombre.toLowerCase()}.jpg" alt="${trabajador.nombre} ${trabajador.apellido}" class="user-avatar">
                    <div class="user-info">
                        <h6>${trabajador.nombre} ${trabajador.apellido}</h6>
                        <p>${trabajador.cargo}</p>
                    </div>
                `;
                userCards.appendChild(userCard);
            });
        })
        .catch(error => console.error('Error al obtener los trabajadores en línea:', error));
}

// Llamar a la función cada 5 segundos para actualizar la lista de trabajadores
setInterval(obtenerTrabajadoresEnLinea, 5000);

// Llamar a la función una vez al cargar la página
window.onload = obtenerTrabajadoresEnLinea;
