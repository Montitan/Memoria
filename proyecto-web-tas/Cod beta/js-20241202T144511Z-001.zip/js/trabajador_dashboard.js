document.addEventListener('DOMContentLoaded', function() {
    // Funcionalidad del modo oscuro
    const darkModeSwitch = document.getElementById('darkModeSwitch');
    darkModeSwitch.addEventListener('change', function() {
      document.body.classList.toggle('dark-mode');
    });
  
    // Funcionalidad de filtrado
    const aplicarFiltros = document.getElementById('aplicar-filtros');
    aplicarFiltros.addEventListener('click', function() {
      const busqueda = document.getElementById('busqueda-global').value.toLowerCase();
      const estado = document.getElementById('filtro-estado').value;
      const prioridad = document.getElementById('filtro-prioridad').value;
      const fecha = document.getElementById('filtro-fecha').value;
  
      const filas = document.querySelectorAll('#tabla-incidencias tbody tr');
      filas.forEach(function(fila) {
        const textoFila = fila.textContent.toLowerCase();
        const estadoFila = fila.querySelector('td:nth-child(2)').textContent;
        const prioridadFila = fila.querySelector('td:nth-child(3)').textContent;
        const fechaFila = fila.querySelector('td:nth-child(4)').textContent;
  
        const cumpleFiltros = 
          textoFila.includes(busqueda) &&
          (estado === '' || estadoFila.includes(estado)) &&
          (prioridad === '' || prioridadFila.includes(prioridad)) &&
          (fecha === '' || fechaFila === fecha);
  
        fila.style.display = cumpleFiltros ? '' : 'none';
      });
    });
  
    // Funcionalidad para crear nueva incidencia
    const nuevaIncidencia = document.querySelector('.btn-primary');
    nuevaIncidencia.addEventListener('click', function() {
      alert('Funcionalidad para crear nueva incidencia');
      // Aquí se implementaría la lógica para abrir un modal o redirigir a una página de creación de incidencias
    });
  
    // Funcionalidad para las acciones de la tabla
    const accionesBotones = document.querySelectorAll('.btn-outline-info, .btn-outline-secondary');
    accionesBotones.forEach(function(boton) {
      boton.addEventListener('click', function(e) {
        e.preventDefault();
        const accion = this.title;
      });
    });
  });

  